package de.moviemanager.ui.masterlist.elements;

import static de.moviemanager.ui.masterlist.elements.Type.DIVIDER;

public class DividerElement extends Element{
    public DividerElement() {
        super(DIVIDER, "");
    }
}
