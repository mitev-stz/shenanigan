package de.util.operationflow;

class TransactionException extends RuntimeException {
    public TransactionException(final String msg) {
        super(msg);
    }
}
