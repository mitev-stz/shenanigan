package de.moviemanager.ui.masterlist.categorizer;

import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Comparator;
import java.util.function.ToDoubleFunction;

import de.moviemanager.data.Nameable;
import de.moviemanager.ui.masterlist.elements.ContentElement;
import de.moviemanager.ui.masterlist.elements.DividerElement;
import de.moviemanager.ui.masterlist.elements.HeaderElement;
import de.util.StringUtils;

import static java.util.Comparator.comparing;

public class Lent<T extends Nameable> extends Categorizer<String, T> {
    private final Comparator<ContentElement<T>> contentComparator =
            comparing(ContentElement<T>::getMeta)
                    .thenComparing(ContentElement::getTitle, StringUtils::alphabeticalComparison);

    private final String numberName;
    private final ToDoubleFunction<T> getNumber;

    private final static String NOT_LENT = "Not Lent";
    private final static String LENT = "Lent";
    private final static String OVERDUE = "Overdue";

    public Lent(final String numberName, final ToDoubleFunction<T> getNumber) {
        this.numberName = numberName;
        this.getNumber = getNumber;
    }

    @Override
    public String getCategoryNameFor(final T obj) {
        long temp = (long)getNumber.applyAsDouble(obj);

        if (temp == 0){
            return NOT_LENT;
        }
            Date date = new Date(temp);
            java.util.Date t = Calendar.getInstance().getTime();
            return date.compareTo(t)<=0? LENT : OVERDUE;

    }

    @Override
    public HeaderElement<T> createHeader(final String category) {
        return new HeaderElement<>(category);
    }

    @Override
    protected ContentElement<T> createContent(final T obj) {
        String name = obj.name();
        long number = (long)getNumber.applyAsDouble(obj);

        String temp = "";
        if (number == 0){
            temp = NOT_LENT;
        }else{
            temp = (new Date(number)).toString();
        }

        return new ContentElement<>(name, numberName + ": " + temp);
    }

    @Override
    public DividerElement createDivider() {
        return new DividerElement();
    }

    @Override
    public int compareCategories(final String cat1, final String cat2) {
        int rank1 = covertCategorieToInteger(cat1);
        int rank2 = covertCategorieToInteger(cat2);
        return Integer.compare(rank1, rank2);
    }

    private int covertCategorieToInteger(final String s){
        if (s == NOT_LENT){
            return 0;
        }else{
            java.util.Date t = Calendar.getInstance().getTime();
            DateFormat f = new SimpleDateFormat("yyyy-MM-dd");
            try{
                java.util.Date d = f.parse(s);
                if(d.compareTo(t)>=0) return 2;
                else return 1;
            } catch (Exception e){
                return 0;
            }
        }
    }


    @Override
    public int compareContent(final ContentElement<T> element1, final ContentElement<T> element2) {
        return contentComparator.compare(element1, element2);
    }
}

